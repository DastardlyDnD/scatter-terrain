Hooks.once('init', async function() {

});

Hooks.once('ready', async function() {

});
